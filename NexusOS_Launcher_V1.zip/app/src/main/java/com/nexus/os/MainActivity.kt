package com.nexus.os

import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    data class AppItem(val label: String, val info: ResolveInfo)

    private lateinit var allApps: List<AppItem>
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<TextView>(R.id.date).text =
            SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(Date())

        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        allApps = pm.queryIntentActivities(intent, 0)
            .map { AppItem(it.loadLabel(pm).toString(), it) }
            .distinctBy { it.label }
            .sortedBy { it.label.lowercase() }

        val names = allApps.map { it.label }.toMutableList()
        adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                v.setBackgroundColor(Color.TRANSPARENT)
                v.findViewById<TextView>(android.R.id.text1).apply {
                    setTextColor(Color.WHITE)
                    textSize = 14f
                    gravity = android.view.Gravity.CENTER
                    setPadding(4, 18, 4, 18)
                }
                return v
            }
        }

        val grid = findViewById<GridView>(R.id.apps)
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, position, _ ->
            val launch = pm.getLaunchIntentForPackage(allApps[position].info.activityInfo.packageName)
            if (launch != null) startActivity(launch)
        }

        findViewById<EditText>(R.id.search).addTextChangedListener(
            object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) {
                    val q = s?.toString()?.trim()?.lowercase() ?: ""
                    val filtered = allApps.filter { it.label.lowercase().contains(q) }.map { it.label }
                    adapter.clear(); adapter.addAll(filtered); adapter.notifyDataSetChanged()
                    grid.setOnItemClickListener { _, _, pos, _ ->
                        val item = allApps.firstOrNull { it.label == filtered[pos] }
                        item?.let { pm.getLaunchIntentForPackage(it.info.activityInfo.packageName)?.let(::startActivity) }
                    }
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            }
        )
    }
}
