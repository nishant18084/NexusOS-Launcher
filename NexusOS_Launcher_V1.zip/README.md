# Nexus OS Launcher V1

This is the first real, runnable Nexus OS prototype: an Android HOME launcher.

What works:
- Can be selected as the phone's default Home app
- Shows a Nexus-style dark home screen
- Live clock/date
- App search
- Reads installed launcher apps
- Launches installed apps
- 4-column app grid

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build/install the app.
4. Press Home and choose "Nexus OS" as the default launcher.

This is a launcher prototype, not a replacement Android operating system yet.
